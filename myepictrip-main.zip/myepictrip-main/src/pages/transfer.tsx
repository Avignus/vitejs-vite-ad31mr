import React from "react";
import { Container, Box, Heading } from "@chakra-ui/react";

export default function Transfer() {
  return (
    <Container >
      <Box w="100%" borderColor="black">
        <Heading color="black">Prefered Language</Heading>
      </Box>
    </Container>
  );
}
